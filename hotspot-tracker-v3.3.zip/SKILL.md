---
name: hotspot-tracker-v3-3
description: "Hotspot Tracker V3.3 - Auto scrape trending data from Douyin, Bilibili, Xiaohongshu, Weibo, GitHub, YouTube, X(Twitter). Generate HTML report with clickable links. Use when user needs: (1) Get today's hot topics, (2) Analyze platform trends, (3) Generate hotspot analysis report, (4) View popular keywords and content suggestions. V3.3: Output directory uses process.cwd() to ensure reports are saved in the calling project folder."
---

# Hotspot Tracker V3.3

One-click multi-platform trending data scraper with auto-generated visual analysis report.

## Quick Start

**First-time setup:**
```bash
cd {skill_path}/scripts
npm install
```

**Run the skill:**
```bash
node {skill_path}/scripts/run.js
```

> ⚠️ **IMPORTANT**: Do NOT change directory before running. Execute the script with its absolute path while staying in the user's working directory. The script uses `process.cwd()` to determine output location, so the current working directory must be where the user wants the output.

Output will be generated in `HotSpotReport/` folder of the **current working directory**:
- `hotspot-data-{date}.json` - Raw data
- `hotspot-report-{date}.html` - Visual report (clickable links)

## Workflow

```
1. Launch Browser -> 2. Parallel scrape 7 platforms -> 3. Analyze data -> 4. Generate HTML report
```

## Core Script

| Script | Function |
|--------|----------|
| `scripts/run.js` | Full pipeline: scrape + analyze + report |

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `OUTPUT_DIR` | `{cwd}/HotSpotReport` | Output directory |
| `HEADLESS` | `true` | Headless mode (set false to see browser) |

## Data Sources (7 Platforms)

| Platform | URL | Method |
|----------|-----|--------|
| Douyin Realtime | `https://www.douyin.com/hot` | API intercept |
| Douyin Rising | `https://www.douyin.com/hot` | API + DOM |
| Bilibili | `https://www.bilibili.com/v/popular/rank/all` | API intercept |
| Xiaohongshu | `https://www.xiaohongshu.com/explore` | API + DOM |
| Weibo | `https://s.weibo.com/top/summary` | DOM parse |
| GitHub Trending | `https://github.com/trending?since=weekly` | DOM parse |
| YouTube | `https://www.youtube.com/feed/trending` | DOM (intl network) |
| X(Twitter) | `https://x.com/explore` | DOM (intl network) |

## V3.3 Updates

1. **Output path optimization** - Always outputs to calling working directory
   - Uses `process.cwd()` to get current working directory
   - Reports generated in user's project folder regardless of where skill is called from
2. **Douyin rising hot optimization** - Increased from 5 to 15 items
3. **Data supplement logic optimization** - No duplicates, no missing items
4. **Stability enhancement** - Added retry mechanism and error handling

## Output Example

**JSON Data Structure**:
```json
{
  "date": "2026-03-22",
  "platforms": [
    {
      "platform": "douyin",
      "hot_list": [{"rank": 1, "title": "...", "hot": 12113768, "url": "https://..."}],
      "rising_list": [{"rank": 1, "title": "...", "hot": 0, "url": "https://..."}]
    }
  ]
}
```

**HTML Report Features**:
- Statistics overview (platforms, data count, max hot)
- Top 15 popular keywords
- Douyin realtime + rising hot TOP 15 (clickable)
- All platforms TOP 15 (clickable)
- Hotspot event tracking (cross-platform analysis)
- 5 content suggestions

## Dependencies

- Node.js 18+
- Playwright (browser auto-installed on first run)

## Troubleshooting

**Browser launch failed**: Run `npx playwright install chromium`

**Data is empty**: Check network, or set `HEADLESS=false`

**YouTube/X failed**: Requires international network access

**Douyin rising hot value is 0**: Extracted from DOM, value may be 0 but titles are accurate
